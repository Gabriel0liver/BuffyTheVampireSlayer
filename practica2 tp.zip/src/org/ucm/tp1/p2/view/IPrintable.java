package org.ucm.tp1.p2.view;

public interface IPrintable {
	
	String getPositionToString(int x, int y);
	String getInfo();
}
